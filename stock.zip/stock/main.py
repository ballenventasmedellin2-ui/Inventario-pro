from fastapi import FastAPI
import pandas as pd
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

FILE = "Inventario stock.xlsx"

def cargar_excel():
    df = pd.read_excel(FILE)
    df.columns = df.columns.str.strip()
    return df

def guardar_excel(df):
    df.to_excel(FILE, index=False)

@app.get("/inventario")
def get_data():
    df = cargar_excel()
    return df.fillna("").to_dict(orient="records")

@app.post("/inventario")
def add_data(item: dict):
    df = cargar_excel()
    df = pd.concat([df, pd.DataFrame([item])], ignore_index=True)
    guardar_excel(df)
    return {"msg": "ok"}

@app.delete("/inventario/{i}")
def delete(i: int):
    df = cargar_excel()
    df = df.drop(index=i)
    guardar_excel(df)
    return {"msg": "eliminado"}